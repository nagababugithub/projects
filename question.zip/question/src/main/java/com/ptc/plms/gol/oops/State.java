package com.ptc.plms.gol.oops;

public enum State {
	LIVE,DEAD;
}
